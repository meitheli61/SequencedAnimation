var CurrentAnimation;
var animationTime = [];
var m_bStartMovingSlider = false;
var moveSliderTimeout;
var currentSpeed = 1.5;
var hero;
var m_bPlayingInReverse = false;
var animationsArray = [];
var reverseAnimationsArray = [];
var animationNumberToPlay = 0;
var myscene;
var m_bLoop = false;
var m_fTotalAnimTime = 0;
var m_bPingPong = false;
var tempSliderVal = 0;
var animationEndTimes = [];
var prevFrame, currentFrame;
var AnimStartedCount = 0;
var AnimToPlay, AnimStyle;
var m_bSeek = false;
var skeletons;
var jumptoFrame;
var animatable;
var animCount = 0;
var animatables = [];

const ANIM_TO_PLAY = {
    PlayAll:1,
    Others:2
}
const ANIM_STYLE = {
    Loop:1,
    PingPong:2,
    OnlyOnce:3
}
Object.freeze(AnimToPlay);
Object.freeze(AnimStyle);